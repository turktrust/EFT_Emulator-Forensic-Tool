﻿using Analiz_Aracı;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace Analiz_Aracı
{


    /// Veri toplama ve diğer işlemler için yardımcı sınıf
    internal static class DirectoryHelper
    {


        /// Drive'da bulunan dosyalar

        private static readonly System.Collections.Generic.HashSet<Tum_Dosyalar_List> tumdosyalarlistesi = new System.Collections.Generic.HashSet<Tum_Dosyalar_List>();
        private static readonly System.Collections.Generic.HashSet<Sanalmakine_List> sanalmakinelistesi = new System.Collections.Generic.HashSet<Sanalmakine_List>();

        /// Drive'da bulunan dizinler

        private static readonly System.Collections.Generic.HashSet<DirectoryDetail> DirectoryDetails = new System.Collections.Generic.HashSet<DirectoryDetail>();

        /// Yetersiz ayrıcalıklar nedeniyle dizinler atlandı. Birçok durumda bağlantı noktaları

        private static readonly System.Collections.Generic.HashSet<string> SkippedDirectories = new System.Collections.Generic.HashSet<string>();

        /// Uzantı istatistikleri

        private static readonly System.Collections.Generic.HashSet<Tum_Dosyalar_Boyut> Tum_Dosya_Boyut = new System.Collections.Generic.HashSet<Tum_Dosyalar_Boyut>();
        private static readonly System.Collections.Generic.HashSet<Sanalmakine_Boyut> Sanal_Makine_Boyut = new System.Collections.Generic.HashSet<Sanalmakine_Boyut>();


        /// Toplama işlemi hakkında bilgi göndermek için kullanılan olay
        internal static event System.EventHandler<string> StatusUpdate;


        /// Genel sayaçların değiştirildiğini bildirmek için kullanılan olay
        internal static event System.EventHandler CountersChanged;


        /// Bir dizinin atlandığını bildirmek için kullanılan olay
        internal static event System.EventHandler<string> DirectorySkipped;


        /// Toplama işleminin durumu değiştiğinde bilgi göndermek için kullanılan olay
        internal static event System.EventHandler<bool> GatherInProgressChanges;


        /// Bir kök düzey dizininin tamamlandığını bildirmek için kullanılan olay
        internal static event System.EventHandler<DirectoryDetail> DirectoryComplete;


        /// Veri toplama için kullanılan görev

        private static System.Threading.Tasks.Task _gatherTask;


        /// Bir toplantının durdurulması isteniyor mu?

        private static bool _stopRequested;


        /// Konular için nesneyi kilitle

        private static object _lockObject = new object();


        /// Genel dosya sayısı

        public static int OverallFileCount { get; set; }


        /// Genel dizin sayısı

        public static int OverallDirectoryCount { get; set; }


        /// Veri toplamanın mevcut durumu

        internal static bool GatherInProgress
        {
            get
            {
                return DirectoryHelper._gatherTask == null ? false : DirectoryHelper._gatherTask.Status == System.Threading.Tasks.TaskStatus.Running;
            }
        }


        /// Veri toplama sürecini başlatır

        /// <param name="drive"></param>
        /// <returns></returns>
        internal static bool StartDataGathering(System.IO.DriveInfo driveInfo)
        {
            DirectoryHelper.tumdosyalarlistesi.Clear();
            DirectoryHelper.sanalmakinelistesi.Clear();
            DirectoryHelper.DirectoryDetails.Clear();

            DirectoryHelper.Tum_Dosya_Boyut.Clear();
            DirectoryHelper.Sanal_Makine_Boyut.Clear();

            DirectoryHelper.SkippedDirectories.Clear();
            DirectoryHelper.OverallDirectoryCount = 0;
            DirectoryHelper.OverallFileCount = 0;
            DirectoryHelper._stopRequested = false;

            DirectoryHelper._gatherTask = new System.Threading.Tasks.Task(() => { GatherData(driveInfo); }, System.Threading.Tasks.TaskCreationOptions.LongRunning);
            DirectoryHelper._gatherTask.Start();

            return true;
        }


        /// Veri toplama sürecini başlatır

        /// <param name="drive"></param>
        /// <returns></returns>
        internal static bool StopDataGathering()
        {
            if (DirectoryHelper._gatherTask.Status != System.Threading.Tasks.TaskStatus.Running)
            {
                return true;
            }
            lock (DirectoryHelper._lockObject)
            {
                DirectoryHelper._stopRequested = true;
            }
            DirectoryHelper._gatherTask.Wait();

            return true;
        }


        /// Hazır sürücülerin bir listesini döndürür

        /// <returns>Sürücü listesi</returns>
        internal static System.Collections.Generic.IEnumerable<System.IO.DriveInfo> GetDrives()
        {
            return System.IO.DriveInfo.GetDrives().Where(drive => drive.IsReady);
        }


        /// Bir sürücü için verileri toplar

        /// <param name="drive">Araştırmak için sürün</param>
        /// <returns>Başarılıysa doğru</returns>
        private static bool GatherData(System.IO.DriveInfo driveInfo)
        {
            DirectoryHelper.RaiseGatherInProgressChanges(true);
            DirectoryHelper.ListFiles(new DirectoryDetail(driveInfo.Name, 0, driveInfo.TotalSize - driveInfo.AvailableFreeSpace));

            DirectoryHelper.RaiseStatusUpdate("İstatistikler Hesaplanıyor...");
            DirectoryHelper.Tum_Dosya_Liste_Doldur();
            DirectoryHelper.Sanal_Liste_Doldur();

            DirectoryHelper.RaiseStatusUpdate("Tamamlandı");
            DirectoryHelper.RaiseGatherInProgressChanges(false);

            return true;
        }


        /// StausUpdate olayını yükseltir

        /// <param name="status">Gönderilecek durum</param>
        private static void RaiseStatusUpdate(string status)
        {
            if (DirectoryHelper.StatusUpdate != null)
            {
                DirectoryHelper.StatusUpdate(null, status);
            }
        }


        /// DirectorySkipped olayını başlatır

        /// <param name="path">Dizinin yolu atlandı</param>
        private static void RaiseDirectorySkipped(string path)
        {
            if (DirectoryHelper.DirectorySkipped != null)
            {
                DirectoryHelper.DirectorySkipped(null, path);
            }
        }


        /// Raises the StateChange event

        /// <param name="status">Süreç için yeni durum</param>
        private static void RaiseGatherInProgressChanges(bool newState)
        {
            if (DirectoryHelper.GatherInProgressChanges != null)
            {
                DirectoryHelper.GatherInProgressChanges(null, newState);
            }
        }


        /// CountersChange olayını yükseltir

        private static void RaiseCountersChanged()
        {
            if (DirectoryHelper.CountersChanged != null)
            {
                DirectoryHelper.CountersChanged(null, new System.EventArgs());
            }
        }


        /// Hashset'lere özyinelemeli olarak dosya ve dizin ekler

        /// <param name="directory">Verilerin toplanacağı dizin</param>
        /// <returns>Dizin ayrıntıları</returns>
        private static DirectoryDetail ListFiles(DirectoryDetail thisDirectoryDetail)
        {
            DirectoryDetail subDirectoryDetail;
            System.IO.FileInfo fileInfo;

            // Exit if stop is requested
            lock (DirectoryHelper._lockObject)
            {
                if (DirectoryHelper._stopRequested)
                {
                    return thisDirectoryDetail;
                }
            }

            RaiseStatusUpdate(string.Format("İnceleniyor: {0}", DirectoryHelper.ShortenPath(thisDirectoryDetail.Path)));

            //Bu dizindeki dosyaları listele
            try
            {
                // Klasörü okuyor ve klasörün Alt dizinleri arasında döngü
                foreach (string subDirectory in System.IO.Directory.EnumerateDirectories(thisDirectoryDetail.Path).OrderBy(x => x))
                {
                    if (subDirectory == subDirectory.Substring(0, 2) + "\\[root]\\var\\snap\\anbox")
                    {
                            var info = new System.IO.DirectoryInfo(subDirectory);
                            string yol = subDirectory;
                            long size = 0;
                            try
                            {
                                foreach (string folder in Directory.GetFiles(yol, "*.*", SearchOption.AllDirectories))
                                {
                                    FileInfo fileInfo1 = new FileInfo(folder);
                                    size += fileInfo1.Length;
                                }

                            }
                            catch (ArgumentException)
                            {                        // Okunamayan alanları listeye aktarıyor
                                lock (DirectoryHelper._lockObject)
                                {
                                    DirectoryHelper.SkippedDirectories.Add(thisDirectoryDetail.Path);
                                }
                                DirectoryHelper.RaiseDirectorySkipped(string.Format("Atlanan {0}, Sebebi: {1}", thisDirectoryDetail.Path, "Dosya Okunamadı"));

                            }
                            catch (NullReferenceException)
                            {                        // Okunamayan alanları listeye aktarıyor
                                lock (DirectoryHelper._lockObject)
                                {
                                    DirectoryHelper.SkippedDirectories.Add(thisDirectoryDetail.Path);
                                }
                                DirectoryHelper.RaiseDirectorySkipped(string.Format("Atlanan {0}, Sebebi: {1}", thisDirectoryDetail.Path, "Dosya Okunamadı"));

                            }
                            sanalmakinelistesi.Add(new Sanalmakine_List()
                            {
                                Name = subDirectory,
                                Path = subDirectory,
                                LastAccessed = info.LastAccessTime,
                                Size = size,
                                Extension = subDirectory,
                            });

                    }

                    subDirectoryDetail = ListFiles(new DirectoryDetail(subDirectory, thisDirectoryDetail.Depth + 1, thisDirectoryDetail));
                    thisDirectoryDetail.CumulativeSize += subDirectoryDetail.CumulativeSize;
                    thisDirectoryDetail.CumulativeNumberOfFiles += subDirectoryDetail.CumulativeNumberOfFiles;
                    thisDirectoryDetail.SubDirectoryDetails.Add(subDirectoryDetail);




                    // Break if stop is requested
                    lock (DirectoryHelper._lockObject)
                    {
                        if (DirectoryHelper._stopRequested)
                        {
                            break;
                        }
                    }
                }

                if (!DirectoryHelper._stopRequested)
                {
                    try
                    {
                        try
                        {
                            foreach (string file in System.IO.Directory.EnumerateFiles(thisDirectoryDetail.Path, "*.*", System.IO.SearchOption.TopDirectoryOnly))
                            {
                                fileInfo = new System.IO.FileInfo(file);

                                lock (DirectoryHelper._lockObject)
                                {

                                    // belirtilen uzantıları dosya yollarında arayıp listeliyor
                                    if (fileInfo.Extension == ".vdi" || fileInfo.Extension == ".vhd" || fileInfo.Extension == ".vhdx"
                                         || fileInfo.Extension == ".vmdk" || fileInfo.FullName == fileInfo.FullName.Substring(0, 2) + "\\[root]\\var\\snap\\anbox")
                                    {
                                        sanalmakinelistesi.Add(new Sanalmakine_List()
                                        {
                                            Name = fileInfo.Name,
                                            Path = fileInfo.DirectoryName,
                                            Size = fileInfo.Length,
                                            LastAccessed = fileInfo.LastAccessTime,
                                            Extension = fileInfo.Extension,
                                            DirectoryDetail = thisDirectoryDetail
                                        });
                                    }

                                    tumdosyalarlistesi.Add(new Tum_Dosyalar_List()
                                    {
                                        Name = fileInfo.Name,
                                        Path = fileInfo.DirectoryName,
                                        Size = fileInfo.Length,
                                        LastAccessed = fileInfo.LastAccessTime,
                                        Extension = fileInfo.Extension,
                                        DirectoryDetail = thisDirectoryDetail
                                    });


                                }





                                thisDirectoryDetail.CumulativeSize += fileInfo.Length;
                                thisDirectoryDetail.Size += fileInfo.Length;
                                thisDirectoryDetail.NumberOfFiles++;
                                thisDirectoryDetail.CumulativeNumberOfFiles++;
                                DirectoryHelper.OverallFileCount++;
                                DirectoryHelper.RaiseCountersChanged();

                            }

                        }
                        catch (FileNotFoundException)
                        {

                            // Okunamayan alanları listeye aktarıyor
                            lock (DirectoryHelper._lockObject)
                            {
                                DirectoryHelper.SkippedDirectories.Add(thisDirectoryDetail.Path);
                            }
                            DirectoryHelper.RaiseDirectorySkipped(string.Format("Atlanan {0}, Sebebi: {1}", thisDirectoryDetail.Path, "Dosya Okunamadı"));

                        }
                    }
                    catch (SystemException)
                    {

                        // Okunamayan alanları listeye aktarıyor
                        lock (DirectoryHelper._lockObject)
                        {
                            DirectoryHelper.SkippedDirectories.Add(thisDirectoryDetail.Path);
                        }
                        DirectoryHelper.RaiseDirectorySkipped(string.Format("Atlanan {0}, Sebebi: {1}", thisDirectoryDetail.Path, "Dosya Okunamadı"));

                    }


                    // List files in this directory

                }

                // bu dizini listview ekle
                lock (DirectoryHelper._lockObject)
                {
                    DirectoryDetails.Add(thisDirectoryDetail);
                }
                DirectoryHelper.OverallDirectoryCount++;
                DirectoryHelper.RaiseCountersChanged();
            }
            catch (System.UnauthorizedAccessException exception)
            {
                // Okunamayan alanları listeye aktarıyor
                lock (DirectoryHelper._lockObject)
                {
                    DirectoryHelper.SkippedDirectories.Add(thisDirectoryDetail.Path);
                }
                DirectoryHelper.RaiseDirectorySkipped(string.Format("Atlanan {0}, Sebebi: {1}", thisDirectoryDetail.Path, exception.Message));
            }
            catch (System.IO.PathTooLongException exception)
            {
                // Yol çok uzun
                lock (DirectoryHelper._lockObject)
                {
                    DirectoryHelper.SkippedDirectories.Add(thisDirectoryDetail.Path);
                }
                DirectoryHelper.RaiseDirectorySkipped(string.Format("Atlanan: {0}, Sebebi: {1}", thisDirectoryDetail.Path, exception.Message));
            }

            if (thisDirectoryDetail.Depth == 1)
            {
                if (DirectoryComplete != null)
                {
                    DirectoryComplete(null, thisDirectoryDetail);
                }
            }

            return thisDirectoryDetail;
        }

        /// Boyuta bağlı olarak baytları bayt, kilobayt megabayt metin vb. olarak biçimlendirir
        /// <"bytes" Gerçek boyutu
        /// biçimlendirilmiş metin
        internal static string FormatBytesText(long bytes)
        {
            string bytesText = null;

            if (bytes < System.Math.Pow(1024, 1))
            {
                bytesText = (bytes / System.Math.Pow(1024, 0)).ToString("N0") + " B";
            }
            else if (bytes < System.Math.Pow(1024, 2))
            {
                bytesText = (bytes / System.Math.Pow(1024, 1)).ToString("N0") + " KB";
            }
            else if (bytes < System.Math.Pow(1024, 3))
            {
                bytesText = (bytes / System.Math.Pow(1024, 2)).ToString("N2") + " MB";
            }
            else if (bytes < System.Math.Pow(1024, 4))
            {
                bytesText = (bytes / System.Math.Pow(1024, 3)).ToString("N2") + " GB";
            }
            return bytesText;
        }


        /// Son dizin görünür olacak şekilde yolu 100 karaktere kısaltır.
        /// Kaldırılan karakterler üç nokta (...) ile değiştirilir
        /// "fullPath" Tam yol
        /// Kısaltılmış yol
        internal static string ShortenPath(string fullPath)
        {
            string shortPath = fullPath;
            System.Text.StringBuilder sb;
            string[] pathParts;
            int partialLength;
            int targetLength = 100;

            if (shortPath.Length > targetLength)
            {
                pathParts = shortPath.Split('\\');
                partialLength = targetLength - 3 - (shortPath.Length - shortPath.LastIndexOf('\\'));
                sb = new System.Text.StringBuilder();
                sb.Append(shortPath.Take(partialLength).ToArray());
                sb.AppendFormat("...\\{0}", pathParts[pathParts.Length - 1]);
                shortPath = sb.ToString();
            }
            return shortPath;
        }


        /// Büyükten küçüğe sıralanmış bir dizindeki tüm dosyaları listeler
        internal static System.Collections.Generic.List<Tum_Dosyalar_List> Tum_Dosyalar_DosyaDizin(DirectoryDetail directoryDetail)
        {
            System.Collections.Generic.List<Tum_Dosyalar_List> fileList;

            lock (DirectoryHelper._lockObject)
            {
                fileList = DirectoryHelper.tumdosyalarlistesi.Where(x => x.DirectoryDetail == directoryDetail).OrderByDescending(x => x.Size).ToList();
            }

            return fileList;
        }
        internal static System.Collections.Generic.List<Sanalmakine_List> Sanal_Makine_DosyaDizin(DirectoryDetail directoryDetail)
        {
            System.Collections.Generic.List<Sanalmakine_List> fileList;

            lock (DirectoryHelper._lockObject)
            {
                fileList = DirectoryHelper.sanalmakinelistesi.Where(x => x.DirectoryDetail == directoryDetail).OrderByDescending(x => x.Size).ToList();
            }

            return fileList;
        }

        internal static System.Collections.Generic.List<Tum_Dosyalar_List> Yoldaki_En_Buyuk_Tum_Dosyalar(DirectoryDetail directoryDetail, int amountToFetch)
        {
            System.Collections.Generic.List<Tum_Dosyalar_List> fileList;

            lock (DirectoryHelper._lockObject)
            {
                fileList = DirectoryHelper.tumdosyalarlistesi.Where(x => x.Path.StartsWith(directoryDetail.Path)).OrderByDescending(x => x.Size).Take(amountToFetch).ToList();
            }

            return fileList;
        }
        internal static System.Collections.Generic.List<Sanalmakine_List> Yoldaki_En_Buyuk_Sanal_Makine(DirectoryDetail directoryDetail, int amountToFetch)
        {
            System.Collections.Generic.List<Sanalmakine_List> fileList;

            lock (DirectoryHelper._lockObject)
            {
                fileList = DirectoryHelper.sanalmakinelistesi.Where(x => x.Path.StartsWith(directoryDetail.Path)).OrderByDescending(x => x.Size).Take(amountToFetch).ToList();
            }

            return fileList;
        }



        /// Dosyalar için istatistikleri hesaplar
        private static bool Tum_Dosya_Liste_Doldur()
        {
            var TumDosyaQuery = from file in DirectoryHelper.tumdosyalarlistesi
                                group file by file.Extension into extensionGroup
                                select new Tum_Dosyalar_Boyut
                                {
                                    Extension = extensionGroup.Key,
                                    TotalBytes = extensionGroup.Sum(file => file.Size)
                                };
            foreach (Tum_Dosyalar_Boyut TumDosya in TumDosyaQuery)
            {
                DirectoryHelper.Tum_Dosya_Boyut.Add(TumDosya);
            }

            return true;
        }
        private static bool Sanal_Liste_Doldur()
        {
            var SanalQuery = from file in DirectoryHelper.sanalmakinelistesi
                             group file by file.Extension into extensionGroup
                             select new Sanalmakine_Boyut
                             {
                                 Extension = extensionGroup.Key,
                                 TotalBytes = extensionGroup.Sum(file => file.Size)
                             };
            foreach (Sanalmakine_Boyut Sanal in SanalQuery)
            {
                DirectoryHelper.Sanal_Makine_Boyut.Add(Sanal);
            }

            return true;
        }


        /// Uzantıları toplam boyuta göre azalan sırada listeler
        internal static System.Collections.Generic.IEnumerable<Tum_Dosyalar_Boyut> Tum_Dosya_Boyut_Sırala()
        {
            return DirectoryHelper.Tum_Dosya_Boyut.OrderByDescending(x => x.TotalBytes);
        }
        internal static System.Collections.Generic.IEnumerable<Sanalmakine_Boyut> Sanal_Boyut_Sırala()
        {
            return DirectoryHelper.Sanal_Makine_Boyut.OrderByDescending(x => x.TotalBytes);
        }


        /// Büyükten küçüğe sıralanmış bir dizindeki tüm dosyaları listeler
        internal static System.Collections.Generic.List<Tum_Dosyalar_List> Uzantiya_Gore_En_Buyuk_TUMDosyalar(string extension, int amountToFetch)
        {
            System.Collections.Generic.List<Tum_Dosyalar_List> dosyalistesi;

            lock (DirectoryHelper._lockObject)
            {
                dosyalistesi = DirectoryHelper.tumdosyalarlistesi.Where(x => x.Extension == extension).OrderByDescending(x => x.Size).Take(amountToFetch).ToList();
            }

            return dosyalistesi;
        }
        internal static System.Collections.Generic.List<Sanalmakine_List> Uzantiya_Gore_En_Buyuk_Sanal_Makineler(string extension, int amountToFetch)
        {
            System.Collections.Generic.List<Sanalmakine_List> dosyalistesi;

            lock (DirectoryHelper._lockObject)
            {
                dosyalistesi = DirectoryHelper.sanalmakinelistesi.Where(x => x.Extension == extension).OrderByDescending(x => x.Size).Take(amountToFetch).ToList();
            }

            return dosyalistesi;
        }

    }
}

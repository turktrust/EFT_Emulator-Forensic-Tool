﻿namespace Analiz_Aracı {

   /// <summary>
   /// Class to contain information about a single files
   /// </summary>
   public sealed class Sanalmakine_List {
      #region Auto-implemented properties
      public string Name { get; set; }
      public string Path { get; set; }
      public long Size { get; set; }
      public System.DateTime LastAccessed { get; set; }
      public string Extension { get; set; }
      public DirectoryDetail DirectoryDetail { get; set; }
      #endregion Auto-implemented properties

      #region Calculated properties
      public string FormattedBytes {
         get {
            return DirectoryHelper.FormatBytesText(this.Size);
         }
      }
      #endregion Calculated properties
   }
}

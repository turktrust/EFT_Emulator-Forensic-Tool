﻿using System.Linq;

namespace Analiz_Aracı {
   
   /// Class to contain information about a directory
   
   public sealed class DirectoryDetail {

        #region Fields
        // Ayrıştırılmış dizin adı
        private string _directoryName = null;
        #endregion Fields

        #region Auto-implemented properties
        
        /// Klasör yolu
        
        public string Path { get; set; }

        
        /// Bu dizindeki dosyaların toplam boyutu.
        /// Alt dizinler dahil değil
        
        public long Size { get; set; }

        
        /// Bu dizindeki veya alt dizinlerdeki dosyaların kümülatif boyutu.
        public long CumulativeSize { get; set; }

        
        /// Dizindeki dosya sayısı
        public long NumberOfFiles { get; set; }

        
        /// Dizindeki ve alt dizinlerindeki kümülatif dosya sayısı
        public long CumulativeNumberOfFiles { get; set; }

        // bunu döndür.Path.EndsWith(":\\")? 0 : this.Path.ToCharArray().Where(x => x == '\\').Count();
        
        /// dizinin derinliği
        
        public int Depth { get; set; }

        
        /// Varsa üst dizin detayı
        public DirectoryDetail ParentDirectoryDetail { get; set; }

        
        /// Alt dizin ayrıntıları
        public System.Collections.Generic.HashSet<DirectoryDetail> SubDirectoryDetails { get; private set; }

        
        /// Toplam disk boyutu
        public static long UsedDiskSize { get; set; }

        #endregion Auto-implemented properties

        #region Calculated properties
        
        /// dizinin adı
        public string DirectoryName {
         get {
            if (this._directoryName == null) {
               this._directoryName = this.Path.Substring(this.Path.LastIndexOf('\\')).TrimStart('\\');
            }
            return this._directoryName;
         }
      }

        
        /// Bu dizin boyutunun toplam boyuttan yüzdesi
        public double SizePercentage {
         get {
            return ((double)this.Size / (double)DirectoryDetail.UsedDiskSize) * 100d;
         }
      }

        
        /// Toplam boyuttan kümülatif boyut yüzdesi
        public double CumulativeSizePercentage {
         get {
            return ((double)this.CumulativeSize / (double)DirectoryDetail.UsedDiskSize) * 100d;
         }
      }

        
        /// Baytların biçimlendirilmiş dize gösterimi
        public string FormattedBytes {
         get {
            return DirectoryHelper.FormatBytesText(this.Size);
         }
      }

        
        /// Baytların biçimlendirilmiş dize gösterimi
        public string FormattedCumulativeBytes {
         get {
            return DirectoryHelper.FormatBytesText(this.CumulativeSize);
         }
      }

        #endregion Calculated properties

        #region Constructors

        
        /// Varsayılan kurucu
        public DirectoryDetail() {
         this.SubDirectoryDetails = new System.Collections.Generic.HashSet<DirectoryDetail>();
      }

        
        /// Yol ve derinlik içeren yapıcı
        /// "path" Dizin yolu
        /// "derinlik" Dizin derinliği
        /// "usedDiskSize" Disk için bayt cinsinden kullanılan alan miktarı
        public DirectoryDetail(string path, int depth, long usedDiskSize)
         : this() {
         this.Path = path;
         this.Depth = depth;
         DirectoryDetail.UsedDiskSize = usedDiskSize;
      }

        
        /// Yol, derinlik ve ana dizine sahip yapıcı
        /// "path" Dizin yolu
        /// "derinlik" Dizin derinliği
        /// "parentDirectoryDetail" Üst dizin
        public DirectoryDetail(string path, int depth, DirectoryDetail parentDirectoryDetail)
         : this(path, depth, DirectoryDetail.UsedDiskSize) {
         this.ParentDirectoryDetail = parentDirectoryDetail;
      }

      #endregion Constructors
   }
}

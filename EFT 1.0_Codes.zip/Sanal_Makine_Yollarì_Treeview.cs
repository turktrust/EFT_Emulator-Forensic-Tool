﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace Analiz_Aracı
{
    internal class Sanal_Makine_Yolları_Treeview
    {
        public int Level
        {
            get;
            set;
        }

        public string Name
        {
            get;
            set;
        }
        public string Yol
        {
            get;
            set;
        }
        public List<Sanal_Makine_Yolları_Treeview> SubItems
        {
            get;
            set;
        }
    }
}

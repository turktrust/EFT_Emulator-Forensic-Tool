﻿namespace Analiz_Aracı
{
    public class Yetikilendirmeli_Baslangic : System.Windows.Application
    {

        [System.STAThread()]
        public static void Main()
        {
            Analiz_Aracı.Yetikilendirmeli_Baslangic application;
            Analiz_Aracı.Analiz_Form browserWindow;
            System.Security.Principal.WindowsIdentity identity;
            System.Security.Principal.WindowsPrincipal principal;
            System.Windows.MessageBoxResult result;
            System.Diagnostics.ProcessStartInfo adminProcess;

            System.Windows.Input.Mouse.OverrideCursor = System.Windows.Input.Cursors.AppStarting;

            { // --- Yükseltilmiş ayrıcalıklar için bildirim kullanma alternatifi

                // Yönetici haklarının yerinde olup olmadığını kontrol edin
                identity = System.Security.Principal.WindowsIdentity.GetCurrent();
                principal = new System.Security.Principal.WindowsPrincipal(identity);

                // Yönetici değilse izin isteyin
                if (!principal.IsInRole(System.Security.Principal.WindowsBuiltInRole.Administrator))
                {
                    result = System.Windows.MessageBox.Show("Uygulama, tüm dosyalara erişmek için yükseltilmiş Yönetici olarak çalıştırılsın mı?",
                       "Analiz Aracı", System.Windows.MessageBoxButton.YesNo, System.Windows.MessageBoxImage.Question);
                    if (result == System.Windows.MessageBoxResult.Yes)
                    {
                        // Uygulamayı yönetici ayrıcalıklarıyla yeniden çalıştırın
                        adminProcess = new System.Diagnostics.ProcessStartInfo();
                        adminProcess.UseShellExecute = true;
                        adminProcess.WorkingDirectory = System.Environment.CurrentDirectory;
                        adminProcess.FileName = System.Diagnostics.Process.GetCurrentProcess().MainModule.FileName;
                        adminProcess.Verb = "runas";
                        try
                        {
                            System.Diagnostics.Process.Start(adminProcess);
                            // yeni süreci başlattıktan sonra çık
                            return;
                        }
                        catch (System.Exception exception)
                        {
                            System.Windows.MessageBox.Show(exception.Message, "Directory size browser",
                               System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Exclamation);
                            return;
                        }
                    }
                }

            } // --- Uygulamayı çalıştır

            application = new Analiz_Aracı.Yetikilendirmeli_Baslangic();
            browserWindow = new Analiz_Aracı.Analiz_Form();

            application.Run(browserWindow);
        }
    }
}
